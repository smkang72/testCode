//
//  NetRadioAppDelegate.h
//  NetRadio
//
//  Created by 아이오교육센터 on 10. 10. 22..
//  Copyright LEE JIEUN 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NetRadioViewController;

@interface NetRadioAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    NetRadioViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet NetRadioViewController *viewController;

@end

