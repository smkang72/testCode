#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

// Audio ToolBox Framework 추가해 주세요
// CFNetwork Framework 도 추가해 주세요
#import <AudioToolbox/AudioQueue.h>
#import <AudioToolbox/ExtendedAudioFile.h>
#import <AudioToolbox/AudioFileStream.h>
#import <AudioToolbox/AudioServices.h>

#import "AudioStreamer.h"

@interface NetRadioViewController : UIViewController {
    IBOutlet UITextField *urlField;
	IBOutlet UIButton *playStopBtn;
	IBOutlet UIActivityIndicatorView *activityCtrl;
	IBOutlet UIProgressView *bufferPercentage;
	
	// 스트림 모듈
	AudioStreamer *_streamer;
	BOOL buffering;
}

@property (nonatomic, retain) AudioStreamer *streamer;

- (IBAction)onPlay:(id)sender;

@end
