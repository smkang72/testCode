#import "NetRadioViewController.h"

@implementation NetRadioViewController

@synthesize streamer = _streamer;

-(AudioStreamer*) streamer {
	if (_streamer == nil) {
		NSString *escapedValue = [(NSString *)CFURLCreateStringByAddingPercentEscapes(nil,(CFStringRef)[urlField text],NULL,NULL,kCFStringEncodingUTF8) autorelease];
		
		NSURL *url = [NSURL URLWithString:escapedValue];
		_streamer = [[AudioStreamer alloc] initWithURL:url];
		
		// 재생 상태가 변경된 경우를 감시(Observing)
		[_streamer addObserver:self
					forKeyPath:@"isPlaying"
					   options:0
					   context:nil];
		// 버퍼 갯수가 변경되었을 때
		[_streamer addObserver:self
					forKeyPath:@"queuePercentage"
					   options:0
					   context:nil];
		
	}
	return _streamer;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		self.title = @"NetRadio";
    }
    return self;
}

- (IBAction)onPlay:(id)sender {
	// 키보드 사라지도록 하자.
	[urlField resignFirstResponder];
	if (self.streamer.isPlaying || buffering) {
		[activityCtrl stopAnimating];
		[self.streamer stop];
	} else {		
		// 상태 인디케이터 표시
		[activityCtrl startAnimating];
		[self.streamer start];
		[playStopBtn setTitle:@"Stop" forState:UIControlStateNormal];
		buffering = YES;
	}
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object
						change:(NSDictionary *)change context:(void *)context
{
	
	NSLog(keyPath);
	if ([keyPath isEqual:@"isPlaying"])
	{		
		NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
		// 상태 표시 중단
		[activityCtrl stopAnimating];
		
		if ([(AudioStreamer *)object isPlaying])
		{
			// 올바로 재생중인 경우
			[playStopBtn setTitle:@"Stop" forState:UIControlStateNormal];
		}
		else
		{
			// 실패한 경우 
			[self.streamer removeObserver:self forKeyPath:@"isPlaying"];
			[self.streamer removeObserver:self forKeyPath:@"queuePercentage"];
			self.streamer = nil;
			[playStopBtn setTitle:@"Play" forState:UIControlStateNormal];
		}
		buffering = NO;
		[pool release];
		return;
	}
	if ([keyPath isEqual:@"queuePercentage"]) 
	{
		[bufferPercentage setProgress:[(AudioStreamer *)object queuePercentage]];
		return;
	}
	
	[super observeValueForKeyPath:keyPath ofObject:object change:change
						  context:context];
}

-(void)dealloc {
    [urlField release];
	[playStopBtn release];
	[activityCtrl release];
	[bufferPercentage release];
	[super dealloc];
}


@end
