//
//  main.m
//  NetRadio
//
//  Created by 아이오교육센터 on 10. 10. 22..
//  Copyright LEE JIEUN 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
// 현재 폴더에 audioStream.h 와 audioStream.m 파일을 복사해 오세요
